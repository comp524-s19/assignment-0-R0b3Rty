pub type c_char = u8;
pub type __u64 = ::c_ulonglong;

pub const SYS_pivot_root: ::c_long = 41;
pub const SYS_gettid: ::c_long = 178;
pub const SYS_perf_event_open: ::c_long = 241;
pub const SYS_memfd_create: ::c_long = 279;
