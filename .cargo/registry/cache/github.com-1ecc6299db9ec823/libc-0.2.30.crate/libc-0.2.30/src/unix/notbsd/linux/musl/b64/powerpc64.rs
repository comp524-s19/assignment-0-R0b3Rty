pub type c_char = u8;
pub type __u64 = ::c_ulong;

pub const SYS_pivot_root: ::c_long = 203;
pub const SYS_gettid: ::c_long = 207;
pub const SYS_perf_event_open: ::c_long = 319;
pub const SYS_memfd_create: ::c_long = 360;
